var config = {
  paths: {
    "epg-front-js": "./EPG_EasyPaymentGateway/js/view/payment/epg-front"
  },
  "map": {
      "*": {
          "Magento_Ui/js/view/messages": "EPG_EasyPaymentGateway/js/view/messages",
          "Magento_Ui/template/messages.html": "EPG_EasyPaymentGateway/template/messages.html"          
      }
  }
};
