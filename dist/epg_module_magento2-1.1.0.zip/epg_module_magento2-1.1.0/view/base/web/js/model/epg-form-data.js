define([], function () {
    'use strict';

    return {
        account: 0,
        epgPaymentMethod: '',
        epgFields: []
    };
});
