var config = {
  paths: {
    "epg-front-js": "./EPG_EasyPaymentGateway/js/view/payment/epg-front"
  }  
};
