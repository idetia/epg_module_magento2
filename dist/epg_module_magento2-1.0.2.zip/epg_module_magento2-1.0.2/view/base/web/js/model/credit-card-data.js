define([], function () {
    'use strict';

    return {
        account: null,
        holdName: null,
        cardNumber: null,
        cardCvn: '120',
        expMonth: null,
        expYear: null
    };
});
