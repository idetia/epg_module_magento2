<?php

namespace EPG\EasyPaymentGateway\Block;

use Magento\Payment\Block\Form as BlockForm;

class Form extends BlockForm
{

}
